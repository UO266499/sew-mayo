package util;

import java.io.File;
import java.util.Scanner;

public class Consola {
	Scanner sc = new Scanner(System.in);
	
	public File pedirDocumento(){
		System.out.println("--> Bienvenido a DisplayTTML!");
		System.out.println();
		System.out.println("--> Los archivos .ttml generalmente son usados para mostrar subtitulos en pantalla!");
		System.out.println();
		System.out.println("--> El primer paso es introducir el archivo .ttml en la carpeta archivos.ttml");
		System.out.println("--> Una vez realizado, pulsar Enter");
		
		// Ver si el usuario da al Enter sin ningun otro caracter 
		String enterPulsado = sc.nextLine();
		while (!enterPulsado.equals("")) {
			System.out.println("--> Pulsar enter sin introducir ning�n caracter mas, gracias.");
			enterPulsado = sc.nextLine();
		}
		
		System.out.println("--> Para continuar debe introducir nombre del documento TTML que desea visualizar: ");
		
		// Recibimos el nombre del archivo.
		String nombre = sc.nextLine();
		
		while(!nombre.contains(".")) {
			System.out.println("--> Introducir un archivo: ");
			nombre = sc.nextLine();
		}
		// Mientras la extension del archivo no sea .ttml, no lo aceptamos y pedimos otro.
		while ( !nombre.split("\\.")[1].equalsIgnoreCase("ttml")) {
			System.out.println("--> ." + nombre.split("\\.")[1] + " no es una extensi�n v�lida.");
			System.out.println("--> Introducir un archivo .ttml: ");
			nombre = sc.nextLine();
		}
		System.out.println();
		
		return new File("archivosTTML/" + nombre);
	}
	
	public void printMensaje(String mensaje) {
		System.out.println(mensaje);
	}

	public File falloEnDocumento() {
		System.out.println("--> Ha habido un fallo encontrando el archivo que ha introducido.");
		System.out.println("--> Para continuar debe introducir nombre del documento TTML que desea visualizar: ");
		
		// Recibimos el nombre del archivo.
		String nombre = sc.nextLine();
		
		// Mientras la extension del archivo no sea .ttml, no lo aceptamos y pedimos otro.
		while (!nombre.split("\\.")[1].equalsIgnoreCase("ttml")) {
			System.out.println("--> ." + nombre.split("\\.")[1] + " no es una extensi�n v�lida.");
			System.out.println("--> Introducir un archivo .ttml: ");
			nombre = sc.nextLine();
		}
		
		System.out.println("--> Dependiendo de los tiempos seleccionados en el archivo, esto puede tardar mas o menos tiempo.");
		System.out.println("--> El contenido se mostrar� en pantalla a continuaci�n: ");
		
		
		return new File("archivosTTML/" + nombre);
	}

	public void espacio() {
		System.out.println();
		
	}
}
