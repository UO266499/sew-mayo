package logica;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import util.Consola;

public class LectorTTML {

	private static Consola console = new Consola();
	private File ttml;
	private List<Subtitulo> subtitulos = new ArrayList<Subtitulo>();
	private List<String> estilos = new ArrayList<String>();
	private List<String> regiones = new ArrayList<String>();
	
	public void add(File documento) {
		ttml = documento;
	}

	public void parse() throws IOException{
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(ttml));
		} catch (FileNotFoundException e) {
			ttml = console.falloEnDocumento();
			parse();
		}
		
		String linea;    
        
		while ( (linea = br.readLine()) != null){  
        	if (linea.contains("<p")) {
        		parseLine(linea);
        	}
        	
        	if (linea.contains("<style")) {
        		parseStyle(linea);
        	}
        	
        	if (linea.contains("<region")) {
        		parseRegion(linea);
        	}
        	
        }  
        br.close();  
        console.printMensaje("--> El archivo se ha leido.");
	}

	private void parseRegion(String linea) {
		String[] corteInicial = linea.split("xml:")[1].split("tts");
		String id = corteInicial[0];
		String displayAlign = corteInicial[1].substring(1);
		String extent = corteInicial[2].substring(1);
		String origin = corteInicial[3].substring(1,corteInicial[3].length()-2);
		regiones.add(id + " " + displayAlign + " "+extent+ " "+ origin);
	}

	private void parseStyle(String linea) {
		String[] corteInicial = linea.split("xml:")[1].split("tts");
		String id = corteInicial[0];
		String textAlign = corteInicial[1].substring(1);
		String font = corteInicial[2].substring(1);
		String fontSize = corteInicial[3].substring(1,corteInicial[3].length()-2);
		estilos.add(id + " " + textAlign + " "+font+ " "+ fontSize );
	}

	private void parseLine(String linea) {
		
		String codigo = linea;
		
		String id = "No encontrado",begin= "No encontrado",end= "No encontrado",style= "No encontrado",region= "No encontrado",contenido= "No encontrado";
		
		String[] cortadaId = codigo.split("id=");
		String[] cortadaBegin = cortadaId[1].split("begin=");
		id = cortadaBegin[0].substring(1,cortadaBegin[0].length()-2);
		String[] cortadaEnd = cortadaBegin[1].split("end=");
		begin = cortadaEnd[0].substring(1,cortadaEnd[0].length()-2);
		String[] cortadaStyle = cortadaEnd[1].split("style=");
		end = cortadaStyle[0].substring(1,cortadaStyle[0].length()-2);
		
		if (cortadaStyle[1].contains("region=")) {
			String[] cortadaRegion = cortadaStyle[1].split("region=");
			style = cortadaRegion[0].substring(1,cortadaRegion[0].length()-2);
			String[] cortadaCerrarAtribs = cortadaRegion[1].split(">");
			region = cortadaCerrarAtribs[0].substring(1,cortadaCerrarAtribs[0].length()-2);
			String[] cortadaCerrarParrafo = cortadaCerrarAtribs[1].split("<");
			contenido = cortadaCerrarParrafo[0];
		}else {
			String[] cortadaCerrarAtribs = cortadaStyle[1].split(">");
			style = cortadaCerrarAtribs[0].substring(1,cortadaCerrarAtribs[0].length()-2);
			String[] cortadaCerrarParrafo = cortadaCerrarAtribs[1].split("<");
			contenido = cortadaCerrarParrafo[0];
		}
		
		subtitulos.add(new Subtitulo(id, begin, end, style, region, contenido));
		
	}

	public void show() throws InterruptedException, ParseException {
		console.printMensaje("--> Dependiendo de los tiempos seleccionados en el archivo, esto puede tardar mas o menos tiempo.");
		console.printMensaje("--> El contenido se mostrar� en pantalla a continuaci�n: ");
		console.espacio();
		
		console.printMensaje("Informaci�n de los estilos:");
		console.espacio();
		for (int i = 0; i < estilos.size(); i++) {
			console.printMensaje(estilos.get(i).toString());
		}
		
		TimeUnit.MILLISECONDS.sleep(2000);
		console.espacio();
		
		console.printMensaje("Informaci�n de las regiones:");
		console.espacio();
		for (int i = 0; i < regiones.size(); i++) {
			console.printMensaje(regiones.get(i).toString());
		}
		
		TimeUnit.MILLISECONDS.sleep(2000);
		
		console.espacio();
		
		for (int i = 0; i < subtitulos.size(); i++) {
			console.printMensaje(subtitulos.get(i).toString());
			TimeUnit.MILLISECONDS.sleep(subtitulos.get(i).getDuracion());
			console.espacio();
		}
	}
	

}
