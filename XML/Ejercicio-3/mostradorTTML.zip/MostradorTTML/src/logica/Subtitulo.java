package logica;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Subtitulo {

	private String inicio;
	private String end;
	private String contenido;
	private String id;
	private String estilo;
	private String region;
	
	public Subtitulo(String id,String begin, String end,String style, String region, String contenido) {
		this.id = id;
		this.inicio = begin;
		this.end = end;
		this.contenido = contenido;
		this.estilo=style;
		this.region = region;
	}

	@Override
	public String toString() {
		return "Region = "	+ region +"\t"+	"Estilo = "	+ estilo +"\t"+	"Id = "+ id+"\n"+
					inicio + " --> " + end + "\n"
							+ contenido;
	}
	
	public long getDuracion() throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
		Date inicioDate = format.parse(inicio);
		Date endDate = format.parse(end);
		return endDate.getTime() - inicioDate.getTime();
	}
	
}
