package main;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import logica.LectorTTML;
import util.Consola;

public class Main {

	private static Consola console = new Consola();
	private static LectorTTML ttml = new LectorTTML();
	
	public static void main(String[] args) throws IOException, InterruptedException, ParseException{
		File documento = console.pedirDocumento();
		
		ttml.add(documento);
		
		ttml.parse();
		
		ttml.show();
	}

}
