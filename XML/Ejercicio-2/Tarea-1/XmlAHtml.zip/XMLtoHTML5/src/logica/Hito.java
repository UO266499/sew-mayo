package logica;

public class Hito {

	String nombre;
	String descripcion;
	String coordenadas;
	String distancia;
	
	public Hito(String nombre, String descripcion, String coordenadas, String distancia) {
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.coordenadas = coordenadas;
		this.distancia = distancia;
	}
	
	

}
