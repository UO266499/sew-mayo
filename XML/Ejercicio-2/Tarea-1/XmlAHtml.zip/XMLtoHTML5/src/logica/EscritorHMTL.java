package logica;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class EscritorHMTL {

	private String numeroDeRuta;
	private String tipo;
	private String dificultad;
	private String duracion;
	private String agencia;
	private String descripcion;
	private String personas;
	private String lugar;
	private String recomendacion;
	private ArrayList<Hito> listaDeHitos = new ArrayList<Hito>();
	File f = new File("index.html");
	BufferedWriter bw;
	
	public EscritorHMTL() throws IOException {
		bw = new BufferedWriter(new FileWriter(f));
	}

	public void execute() throws IOException {
		if (numeroDeRuta.charAt(5) == '1') {
	        bw.write("<!DOCTYPE html>\r\n" + 
	        		"\r\n" + 
	        		"<html lang=\"es\"> <!-- declaracion del idioma del archivo-->\r\n" + 
	        		"\r\n" + 
	        		"    <head>\r\n" + 
	        		"     <link href=\"estilo.css\" rel=\"stylesheet\" type=\"text/css\"/>\r\n" + 
	        		"     <!-- Metadata del archivo -->\r\n" + 
	        		"     <meta charset=\"utf-8\"/>\r\n" + 
	        		"        <title>Rutas a Caballo</title> \r\n" + 
	        		"    </head>");
	        bw.write("<body> \n"); 
	        bw.write("<main> \n");
	        bw.write("<section> \n");
			
		}
	
		 bw.append("<h"+numeroDeRuta.charAt(5)+ ">" + numeroDeRuta + "</h"+numeroDeRuta.charAt(5)+">"+"\n");
		 bw.append("<p>"+tipo+"</p>\n");
		 bw.append("<p>"+dificultad+"</p>\n");
		 bw.append("<p>"+descripcion+"</p>\n");
		 bw.append("<p>"+agencia+"</p>\n");
		 bw.append("<p>"+duracion+"</p>\n");
		 bw.append("<p>"+lugar+"</p>\n");
		 bw.append("<p>"+personas+"</p>\n");
		 bw.append("<p>"+recomendacion+"</p>\n");
		 
		 if(!listaDeHitos.isEmpty()) {
			 int i = 1;
			 for (Hito hito : listaDeHitos) {
				 bw.append("<p>"+"Hito numero: "+i+"</p>\n");
				 bw.append("<p>"+hito.nombre+"</p>\n");
				 bw.append("<p>"+hito.descripcion+"</p>\n");
				 bw.append("<p>"+"Distancia: "+hito.distancia+"</p>\n");
				 bw.append("<p>"+"Coordenadas: "+hito.coordenadas+"</p>\n");
				 i++;
			}
		 }
		
		if (numeroDeRuta.equalsIgnoreCase("ruta 3")) {
	        bw.append("</section>\n");
	        bw.append("</main>\n");
	        bw.append("</body> \n");
	        bw.close();
		}
	}

	public void setNumeroDeRuta(String numeroDeRuta) {
		this.numeroDeRuta = numeroDeRuta;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public void setDificultad(String dificultad) {
		this.dificultad = dificultad;
	}

	public void setDuracion(String duracion) {
		this.duracion = duracion;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public void setPersonas(String personas) {
		this.personas = personas;
	}

	public void setLugar(String lugar) {
		this.lugar = lugar;
	}

	public void setRecomendacion(String recomendacion) {
		this.recomendacion = recomendacion;
	}

	public void setListaDeHitos(ArrayList<Hito> listaDeHitos) {
		this.listaDeHitos = listaDeHitos;
	}
	
	

	
}
