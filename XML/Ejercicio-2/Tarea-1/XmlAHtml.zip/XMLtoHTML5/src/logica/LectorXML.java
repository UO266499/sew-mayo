package logica;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class LectorXML {

	private File file;
	private EscritorHMTL escritor;

	public LectorXML(File file) throws IOException {
		this.file = file;
		  escritor = new EscritorHMTL();
	}

	public void execute() {
		try {
			File xml = this.file;
			
			DocumentBuilderFactory factory= DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = factory.newDocumentBuilder();
			Document doc = docBuilder.parse(xml);
			
			doc.getDocumentElement().normalize();
			
			NodeList nodes = doc.getElementsByTagName("ruta");
			
			for (int i = 0; i < nodes.getLength(); i++) {
				Node node = nodes.item(i);
				
				String numRuta = "No encontrado", tipo= "No encontrado", dificultad= "No encontrado", duracion= "No encontrado", agencia= "No encontrado", lugar= "No encontrado", descripcion= "No encontrado", personas= "No encontrado", recomendacion= "No encontrado";
				ArrayList<Hito> listaDeHitos = new ArrayList<Hito>();
				
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element element = (Element) node;
					numRuta= "ruta " + (i + 1);
					
					tipo = "Tipo de ruta : " + element.getElementsByTagName("tipo").item(0).getTextContent();
					
					dificultad = "Dificultad de la ruta : " + element.getElementsByTagName("dificultad").item(0).getTextContent();
					
					duracion = "Duracion de la ruta: " + element.getElementsByTagName("duracion").item(0).getTextContent();
					
					agencia = "Agencia: " + element.getElementsByTagName("agencia").item(0).getTextContent();
					
					descripcion = "Descripcion: " + element.getElementsByTagName("descripcion").item(0).getTextContent();
					
					lugar = "Lugar de inicio: " + element.getElementsByTagName("lugar").item(0).getTextContent();
					
					personas = "Para las personas: " + element.getElementsByTagName("personas").item(0).getTextContent();
					
					recomendacion = "Recomendacion: " + element.getElementsByTagName("recomendacion").item(0).getTextContent();
					
					NodeList nodesHito = doc.getElementsByTagName("hito");

					for (int j = 0; j < nodes.getLength(); j++) {
						Node node2 = nodesHito.item(i);
						
						String nombre = "No encontrado", descripcion2 = "No encontrado", coordenadas = "No encontrado", distancia = "No encontrado";
						
						if (node2.getNodeType() == Node.ELEMENT_NODE) {
							Element element2 = (Element) node2;
							
							nombre = "Nombre : " + element2.getElementsByTagName("nombre").item(0).getTextContent();
							
							descripcion2 = "Descripcion: " + element2.getElementsByTagName("descripcion").item(0).getTextContent();
							
							coordenadas = "Coordenadas: " + element2.getElementsByTagName("coordenadas").item(0).getTextContent();
							
							distancia = "Distancia: " + element2.getElementsByTagName("distancia").item(0).getTextContent();
							
							Hito hito = new Hito(nombre,descripcion2,coordenadas, distancia);
							listaDeHitos.add(hito);
						}
					
					}
				}
				escritor.setNumeroDeRuta(numRuta);
				escritor.setTipo(tipo);
				escritor.setDificultad(dificultad);
				escritor.setDuracion(duracion);
				escritor.setAgencia(agencia);
				escritor.setDescripcion(descripcion);
				escritor.setPersonas(personas);
				escritor.setLugar(lugar);
				escritor.setRecomendacion(recomendacion);
				escritor.setListaDeHitos(listaDeHitos);
				escritor.execute();
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
